# Instructions

- Open `workspace.mat`
- Execute `main.slx`

Remember to check the files in the `UsefulScripts` directory